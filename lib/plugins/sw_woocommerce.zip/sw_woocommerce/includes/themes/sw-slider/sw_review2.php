 <div id="<?php echo 'latest_review_' .rand().time(); ?>" class="responsive-slider sw-latest-review2 loading" data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>"  data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
    <?php if( $title1 != '' ) : ?>
      <div class="box-slider-title">    
        <h2 class="page-title-slider"><?php echo ( $title1 != '' ) ? $title1 : $term_name; ?></h2>
        <?php echo ( $description != '' ) ? '<div class="slider-description">'. $description .'</div>' : ''; ?>
      </div>   
    <?php endif; ?>
    <div class="resp-slider-container">
      <div class="slider responsive"> 
        <?php 
        $comments = get_comments( array( 'orderby' => 'comment_date', 'order' => 'DESC', 'post_type' => 'product', 'status' => 'approve', 'number' => $numberposts ) );
        foreach( $comments as $key => $comment ) {
          $item_review = get_comment_meta( $comment->comment_ID, 'rating', true );
          ?>
          <div class="item item-comment">
            <div class="item-content-top">
              <div class="item-revivew" >
                <span style="width:<?php echo esc_attr( 21*intval( $item_review ) . 'px' ); ?>"></span>
              </div>
            </div>  
            <div class="item-post">
              <?php 
              $comment_post = '<a href="'. get_permalink( $comment->comment_post_ID ) .'"> '. get_the_title( $comment->comment_post_ID ) .'</a>';
              echo sprintf( __( '%s', 'sw_woocommerce' ), $comment_post ); 
              ?>            
            </div>      
            <div class="item-content">
              <?php echo wp_trim_words( $comment->comment_content, $length, '...' ); ?> 
            </div>  
            <div class="item-date">
              <span><?php echo esc_html( $comment->comment_author ); ?>, </span>
              <?php $post_time = get_comment_date( 'Y-m-d', $comment->comment_ID ); ?>
              <?php echo $post_time; ?>
            </div>
          </div>
          <?php 
        }
        ?>
      </div>
    </div>
  </div>